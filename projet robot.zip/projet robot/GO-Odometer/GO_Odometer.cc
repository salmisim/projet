/*******************************************************************************
 Projektname:       Go - Odometer.cprj
 Ben�tigte Libs�s:  IntFunc_lib.cc
 Routinen:          GO_Odometer.cc, PRO-BOT128C_Lib.cc
 Autor:             UlliS
 Datum:             03.02.2009

 Funktion:          PRO-BOT128 f�hrt 50cm geradeaus, dreht danach um 180�
                    und f�hrt die Strecke wieder zur�ck. Dreht dann wieder
                    um 180� und bleibt stehen.
                    Sollte Ihr PRO-BOT128 nicht Geradeausfahren, sondern sich nur im
                    Kreis drehen oder die Wegstrecke nicht stimmen,
                    m�ssen die Odometer-Sensoren (D2, T3 sowie T3, D4) justiert
                    werden. Dies kann sich durchaus als "Gefummel" herausstellen!
                    Die Bauteile D2, T3 sowie T3, D4 sollten dabei vorsichtig Richtung
                    Encoderscheiben gedr�ckt werden. Als Encoderscheibe wurde in
                    diesen Beispiel, die mit den vier schwarzen Fl�chen verwendet.
                    Es hilft auch zudem die Encoderscheiben mit schwarzem Edding-Stift
                    nachzuschw�rzen. Hier ist ein wenig Fingerspitzengef�hl und Ausdauer
                    gefragt ;-) Zudem sollte es nicht zu hell sein, da die
                    Foto-Transistoren bereits bei Sonnen-Einstrahlung durchsteuern.

*******************************************************************************/

void main(void)
{

    PRO_BOT128_INIT();   //PRO-BOT128 System Init

    AbsDelay(1000);      //Wait 1Sec.
    BLL_ON();            //Back LED left "ON"
    BLR_ON();            //Back LED right "ON"
    ENC_LED_ON();        //Encoder IR-LEDs "ON"
    DRIVE_ON();          //Drive "ON"
    BEEP(350,500);       //Beep

    //Drive Forward 50cm, Turn 180�, Drive Forward 50cm, Turn 180�
    GO_TURN(50,0,180);
    GO_TURN(0,180,160);
    GO_TURN(50,0,180);
    GO_TURN(0,180,160);

    DRIVE_OFF();         //Drive "OFF"
    ENC_LED_OFF();       //Encoder LEDs "OFF"
    BEEP(250,400);       //Beep
    BEEP(350,250);
    BEEP(250,400);
}



