/*******************************************************************************
 Projektname:       Door_Bell.cprj
 Ben�tigte Libs�s:  IntFunc_lib.cc
 Routinen:          Bell.cc, PRO-BOT128C_Lib.cc
 Autor:             UlliS
 Datum:             03.02.2009

 Funktion:          Door Bell (Sound Demo)
*******************************************************************************/


void main(void)
{
    PRO_BOT128_INIT();

    BEEP(110, 250);
    BEEP(140, 350);
    BEEP(125, 250);
    BEEP(180, 400);

    DELAY_MS(200);

    BEEP(200, 300);
    BEEP(135, 250);
    BEEP(120, 250);
    BEEP(145, 400);
}

