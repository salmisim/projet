/*******************************************************************************
 Projektname:       Drive.cprj
 Ben�tigte Libs�s:  IntFunc_lib.cc
 Routinen:          Drive.cc, PRO-BOT128C_Lib.cc
 Autor:             UlliS
 Datum:             03.02.2009

 Funktion:          Geregelte Vorw�rtsfahrt
*******************************************************************************/

void main(void)
{

    PRO_BOT128_INIT();    //PRO-BOT128 Setup

    AbsDelay(1000);       //Wait 1Sec.
    BLL_ON();             //Back LED left "ON"
    BLR_ON();             //Back LED right "ON"
    ENC_LED_ON();         //Encoder IR-LEDs "ON"
    DRIVE_ON();           //Motor "ON"

    do                    //Endless Loop
     {
        DRIVE_FORWARD(5); //Value 1 To 10
        DELAY_MS(100);
     } while (1);

}
