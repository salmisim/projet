/*******************************************************************************
 Projektname:       Lichtsuche.cprj
 Ben�tigte Libs�s:  IntFunc_lib.cc
 Routinen:          Lightsearch.cs, PRO-BOT128C_Lib.cc
 Autor:             UlliS
 Datum:             03.02.2009

 Funktion:          PRO-BOT128 sucht die hellste Stelle im Raum.
                    Am besten man dunkelt den Raum ab, und leuchtet den
                    Roboter mit der Taschenlampe an. PRO-BOT128 wird
                    den Lichtstrahl Ihrer Taschenlampe folgen.

*******************************************************************************/

void main(void)
{

    PRO_BOT128_INIT();      //PRO-BOT128 System Setup
    DRIVE_INIT();           //Drive setup
    ENC_LED_ON();           //Encoder IR-LEDs "ON"
    DRIVE_ON();             //Drive "ON"

    do                      //Endless Loop
     {
       Start:               //Label Start

       //Drive forward 30cm, Speed = 150 (1 To 255)
       GO_TURN(30,0,170);

       /****************************************
        *** LDR check where it is brighter?  ***
        ***************************************/

       //The left is brighter than it is right...
       if (LDR_RIGHT() > LDR_LEFT())
         {
          if ((LDR_RIGHT() - LDR_LEFT()) >= 1)
            {
             GO_TURN(0,-35,180);
             goto Start;
            }
          }


       //Right, it is brighter than the left...
       if (LDR_LEFT() > LDR_RIGHT())
         {
          if ((LDR_LEFT() - LDR_RIGHT()) >=1)
            {
             GO_TURN(0,35,180);
            }
          }

       goto Start;

     } while (1);
}

