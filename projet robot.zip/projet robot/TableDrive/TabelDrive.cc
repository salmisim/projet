/*******************************************************************************
 Projektname:       Tabel Drive.cprj
 Ben�tigte Libs�s:  IntFunc_lib.cc
 Routinen:          Tabel Drive.cc, PRO-BOT128C_Lib.cc
 Autor:             UlliS
 Datum:             03.02.2009

 Funktion:          PRO-BOT128 f�hrt innerhalb eines Wei�en Spielfeldes umher.
                    Das Spielfeld ist schwarz eingerahmt. (Klebeband)
                    Der schwarze Rand muss mindestens 2cm dick sein.
                    PRO-BOT128 wird die schwarze Linie erkennen, und
                    daraufhin ausweichen.

*******************************************************************************/

//Define Port Bits
#define Line_LED 20
#define Motor_Enable 15

//Status LEDs
#define FLL 19
#define FLR 18
#define BLL 17
#define BLR 16

#define Line_Level 100

//Variable
char Text[40];
word Line_Left, Line_Right;


//main programm
void main(void)
{

    Port_DataDir(5,0);                  //Port is Input

    //Status LEDs
    Port_DataDirBit(FLL,PORT_OUT);      //Port PC.0 = Output
    Port_DataDirBit(FLR,PORT_OUT);      //Port PC.1 = Output
    Port_DataDirBit(BLL,PORT_OUT);      //Port PC.2 = Output
    Port_DataDirBit(BLR,PORT_OUT);      //Port PC.3 = Output

    Port_WriteBit(FLL,PORT_OFF);        //front LED left "OFF"
    Port_WriteBit(FLR,PORT_OFF);        //front LED right "OFF"
    Port_WriteBit(BLR,PORT_OFF);        //back LED right "OFF"
    Port_WriteBit(BLL,PORT_OFF);        //back LED left "OFF"

    //Line LED "ON"
    Port_DataDirBit(Line_LED,PORT_OUT); //Port PC.4 = Output
    Port_WriteBit(Line_LED,PORT_ON);    //Line LED "ON"
    AbsDelay(1000);                     //Wait 1Sec.
    Port_WriteBit(Line_LED,PORT_OFF);   //Line LED "OFF"
    AbsDelay(1000);                     //Wait 1Sec.
    Port_WriteBit(Line_LED,PORT_ON);    //Line LED "ON"

    //Motor setup
    Motor_Init();


    do                                   //Endless Loop
      {
        //Read Linesensor
        Line_Left = GetAdc(1);
        Line_Right = GetAdc(2);

        /*
        'Led Line values (white pitch black border)
        '1. Values in the white field measure
        '2. Values of the black border measure
        '3. alues may change Line_Level should be in the middle of white And black are

        Msg_WriteWord(Line_Left)        'ADC output value of output window
        Text = " Line_Left"             'Set Identifier
        Msg_WriteText(Text)             'Identifier spend behind ADC_Wert
        Msg_WriteChar(13)               'Line break (new line)

        Msg_WriteWord(Line_Right)       'ADC output value of output window
        Text = " Line_Right"            'Set Identifier
        Msg_WriteText(Text)             'Identifier spend behind ADC_Wert
        Msg_WriteChar(10)               'Line Feed
        Msg_WriteChar(13)               'Line break (new line)
        AbsDelay(500)                   'Wait 500ms
        */

        //35 is standard value, possibly on the above measurement adapt
        if ((Line_Left > Line_Level) && (Line_Right > Line_Level)) Forward();
        if ((Line_Left <= Line_Level) && (Line_Right <= Line_Level)) Turn();

     } while (1);
}


//ADC out of GetAdc
word GetAdc(byte Channel)
{
    //Uref 2.56 V internal reference voltage!
    ADC_Set(ADC_VREF_BG,Channel);
    return ADC_Read();
}

void Motor_Init(void)
{
    Timer_T1PWMX(255,1,1,PS_1);                  //Config For Channel A And B Timer1
    Port_DataDirBit(Motor_Enable,PORT_OUT);      //Port Enable Motor = Output
    Port_WriteBit(Motor_Enable,1);               //Port = High +5V
    Timer_T1PWA(128);                            //Pulse / pause = 50/50 channel-A
    Timer_T1PWB(128);                            //Pulse / pause = 50/50 channel-B
}

void Forward(void)                               //Drive Forward
{
    Timer_T1PWA(200);                            //Speed = 210
    Timer_T1PWB(200);                            //Speed = 210
}

void Turn(void)                                  //Turn
{
    Timer_T1PWA(128);                            //Stop motors
    Timer_T1PWB(128);
    AbsDelay(200);                               //Wait 200ms
    Timer_T1PWA(50);                             //Drive backward
    Timer_T1PWB(50);
    AbsDelay(600);                               //Wait 800ms
    Timer_T1PWA(180);                            //Turn
    Timer_T1PWB(30);
    AbsDelay(800);                               //Wait 1Sec.
}


