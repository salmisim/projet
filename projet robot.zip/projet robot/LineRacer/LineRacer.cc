/*******************************************************************************
 Projektname:       LineRacer.cprj
 Ben�tigte Libs�s:  IntFunc_lib.cc
 Routinen:          LineRacer.cc, PRO-BOT128C_Lib.cc
 Autor:             UlliS
 Datum:             03.02.2009

 Funktion:          PRO-BOT128 folgt einer schwarzen Linie auf den Boden.
                    Dazu m�ssen wir uns einen hellen Untergrund z.B. einen
                    Parket Boden oder eine gro�e wei�e Pappe suchen.
                    Darauf kleben wir mit schwarzem Isolierband (etwa 2cm breit)
                    eine Kreisrunde Bahn auf (Durchmesser etwa 1m oder gr��er).
                    Nat�rlich kann die Bahn auch andere Formen besitzen, wichtig
                    die Kurvenradien sollten aber nicht zu klein sein!
                    Unser Roboter wird auf die so auf die Linie gestellt, das
                    ein Fototransitor (T1) auf die schwarze Line blickt, und der
                    andere (T2) auf den hellen Untergrund. Im Raum darf es auch
                    nicht zu hell sein, da sonst die Kontrastunterschiede zwischen
                    Untergrund und der Line zu klein werden, und der Roboter der
                    Klebebandspur nicht richtig folgen kann.
                    Nach dem wir den Roboter richtig platziert haben, schalten wir
                    unseren PRO-BOT128 ein. Die Line LED muss nach 1Sekunde
                    einschalten, und der Roboter folgt der Linie.
                    Sollte er in den Kurven ausbrechen, m�ssen die Regler Parameter
                    P, I, D ver�ndert werden und evtl. T1 und T2 leicht justiert
                    werden, bis der  Roboter der Linie sauber folgt. Der Abstand
                    von T1, T2 und D1 sollte etwa 5mm zur Fahrbahn betragen!
                    Hier ist eventuell etwas Basteln und Forschergeist gefragt!

*******************************************************************************/

//PID Controller varibale
byte Speed, Left_Dir, Right_Dir;
int Speed_Left, Speed_Right, Line_Sensor[2];
int x, xalt, don, diff, P, D, I, P1, D1, I1, drest, y1, y2, sum;


void main(void)
{
    PRO_BOT128_INIT();                             //System setup
    DRIVE_ON();                                    //Drive setup

    MOTOR_DIR(1,1);                                //Set up To drive forward
    Speed = 240;                                   //Speed value is 150
    P = 5;                                         //PID Parameter (To experience)
    I = 10;
    D = 25;
    Speed_Left = Speed;                            //Speed transfer
    Speed_Right = Speed;


    //Main programm, endless Loop
    do
     {
       LineFollow();                               //Call the LineFollow Code
     }while (1);

}


void LineFollow(void)
{

   LINE_LED_OFF();
   Line_Sensor[0] = READ_LINE_LEFT();              //Measurement with LED off
   Line_Sensor[1] = READ_LINE_RIGHT();             //Values of the photo transistors pick up
   diff = Line_Sensor[0] - Line_Sensor[1];         //To compensate For ambient light
   LINE_LED_ON();
   Line_Sensor[0] = READ_LINE_LEFT();              //Measurement with LED on
   Line_Sensor[1] = READ_LINE_RIGHT();             //Values of the photo transistors pick up
   don = Line_Sensor[0] - Line_Sensor[1];
   x = don - diff;                                 //Rule deviation

   sum = sum + x;
   if (sum > 20000) sum = 20000;                   //Limit To avoid overflow
   if (sum < -20000) sum = -20000;

   I1 = sum / 625 * I;                             //Calculate I part
   D1 = (x - xalt) * D;                            //D-share calculated And compared with
   D1 = D1 + drest;                                //Take rest add

   if (D1 > 255)
     {
      drest = D1 - 255;                             //Hold rest
     }
    else
     {
      if (D1 < -255)
        {
         drest = D1 + 255;
        }
       else drest = 0;
      }

   P1 = x * P;                                     //Calculate P part
   y1 = P1+I1+D1;                                  //Substitute size of the PID controller calculate
   y2 = y1 / 2;                                    //Sharing on both engines
   xalt = x;                                       //Hold X

   Speed_Left = Speed;
   Speed_Right = Speed;

   MOTOR_DIR(1,1);                                 //Set To forward
   if (y1 > 0)                                     //Drive right
     {
      Speed_Left = Speed + y2;                     //Left accelerate
      if (Speed_Left > 255)
        {
          Speed_Left = 255;                        //Limit
          y2 = Speed_Left - Speed;                 //Then consider the right balance
        }

      y1 = y1 - y2;
      Speed_Right = Speed - y1;                    //Right slow
      if (Speed_Right < 0)
        {
          Speed_Right = 0;
        }
      }


   if (y1 < 0)                                     //Left
     {
      Speed_Right = Speed - y2;                    //Right speed
      if (Speed_Right > 255)
        {
          Speed_Right = 255;                       //Limit
          y2 = Speed - Speed_Right;                //Then left the rest take into account
        }

      y1 = y1 - y2;
      Speed_Left = Speed + y1;                     //Slow down the left
      if (Speed_Left < 0)
        {
          Speed_Left = 0;
        }
      }


   MOTOR_DIR(1,1);                                 //Set up toforward
   MOTOR_POWER(ABS_INT(Speed_Left),ABS_INT(Speed_Right)); //Values To the engine driver (PWM)
}

