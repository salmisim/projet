/*******************************************************************************
 Projektname:       Klapper.cprj
 Ben�tigte Libs�s:  IntFunc_lib.cc
 Routinen:          Klapper.cc, PRO-BOT128C_Lib.cc
 Autor:             UlliS
 Datum:             03.02.2009

 Funktion:          PRO-BOT128 reagiert auf Klatschen.
                    Es sollte im Raum nicht zu laut sein!
                    Notfalls kann die SOUND_LEVEL() Schwelle (Value = 700)
                    erh�ht werden. Bei einmaligen klatschen schalten sich die
                    vier Status LEDs ein. Ein weiteres Klatschen veranlasst,
                    das unser Roboter einen kleinen Tanz auff�hrt :-)

*******************************************************************************/

byte Klapp;                         //Counter variable

void main(void)                     //Main Programm
{
    PRO_BOT128_INIT();              //PRO-BOT128 System setup
    DRIVE_INIT();                   //Drive setup
    ENC_LED_ON();                   //Encoder LEDs "ON"

    Klapp = 0;                      //Counter Var set To zero

    BEEP(250,150);                  //Play Sound
    BEEP(100,150);                  //Play Sound
    AbsDelay(500);

    do                              //Endless Loop
     {

       if (SOUND_LEVEL() > 700)     //Sound level larger Then value 700 increment Var Klapp +1
         {
          Klapp = Klapp + 1;
          AbsDelay(100);            //Wait 100ms
         }

       switch (Klapp)               //Select Variable count
        {
         case 1:                    //Varibale Klapp is 1 Then LEDs "ON"
          Lights();
          break;

         case 2:                    //Variable Klapp is 2 Or bigger = "Robo-Dance"
          Moving();
          break;

         default:
          Klapp = 0;
          break;
         }


      } while (1);
}


void Lights(void)                  //All Status LEDs "ON"
{
    FLL_ON();
    FLR_ON();
    BLL_ON();
    BLR_ON();
}

void Moving(void)                   //Robo-Dance
{
    FLL_OFF();                      //All Status LEDs "OFF"
    FLR_OFF();
    BLL_OFF();
    BLR_OFF();
    DRIVE_ON();                     //Motor "ON"
    GO_TURN(0,90,180);              //Turn 90� right, Speed = 180 (1 To 255)
    GO_TURN(0,-180,180);            //Turn 180� left, Speed = 180 (1 To 255)
    GO_TURN(0,90,180);              //Turn 90� right, Speed = 180 (1 To 255)
    DRIVE_OFF();                    //Motor "OFF"
    AbsDelay(250);                  //Wait 250ms
    Klapp = 0;                      //Reset Varibale Klapp To zero
    BEEP(250,150);                  //Play Sound
    BEEP(100,150);                  //Play Sound
    BEEP(250,150);                  //Play Sound
    AbsDelay(500);                  //Wait a moment bevor jump back
}

